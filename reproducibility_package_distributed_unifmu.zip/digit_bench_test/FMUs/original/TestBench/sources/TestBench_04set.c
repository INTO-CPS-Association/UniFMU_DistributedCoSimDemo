/* Initial State Set */
#include "TestBench_model.h"
#include "TestBench_11mix.h"
#include "TestBench_12jac.h"
#if defined(__cplusplus)
extern "C" {
#endif
/* funtion initialize state sets */
void TestBench_initializeStateSets(int nStateSets, STATE_SET_DATA* statesetData, DATA *data)
{
}

#if defined(__cplusplus)
}
#endif

