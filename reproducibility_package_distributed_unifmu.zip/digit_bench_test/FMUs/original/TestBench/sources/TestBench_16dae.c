/* DAE residuals is empty */
 #include "TestBench_model.h"
#ifdef __cplusplus
extern "C" {
#endif
int TestBench_initializeDAEmodeData(DATA* data, DAEMODE_DATA* daeModeData){ return -1; }
#ifdef __cplusplus
}
#endif
