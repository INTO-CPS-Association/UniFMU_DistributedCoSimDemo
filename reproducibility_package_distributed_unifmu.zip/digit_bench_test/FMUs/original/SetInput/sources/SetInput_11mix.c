/* Mixed Systems */
#include "SetInput_model.h"
#include "SetInput_11mix.h"
/* initial mixed systems */
/* initial_lambda0 mixed systems */
/* parameter mixed systems */
/* model mixed systems */
/* jacobians mixed systems */


