/* Initial State Set */
#include "Dut_model.h"
#include "Dut_11mix.h"
#include "Dut_12jac.h"
#if defined(__cplusplus)
extern "C" {
#endif
/* funtion initialize state sets */
void Dut_initializeStateSets(int nStateSets, STATE_SET_DATA* statesetData, DATA *data)
{
}

#if defined(__cplusplus)
}
#endif

