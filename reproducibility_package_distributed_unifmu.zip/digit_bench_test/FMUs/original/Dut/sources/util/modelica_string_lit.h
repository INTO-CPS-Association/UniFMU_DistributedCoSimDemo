#ifndef __META_MODELICA_STRING_LIT__H
#define __META_MODELICA_STRING_LIT__H
extern void *mmc_emptystring;
extern void *mmc_strings_len1[256];
extern void *mmc_string_uninitialized;
extern void *mmc_strings_boolString[2];
#endif
